<html>
  <head>
    <link rel="stylesheet" type="text/css" href="item2.css">
  </head>
  <body>
    <div class='outeri'>
      <div class='pici'>
        <img width='350px'src='https://rukminim1.flixcart.com/image/704/704/shirt/s/h/y/46-bfrybluesht02-being-fab-original-imaekjr8ymhnxznp.jpeg'>
      </div>
      <div class='infoi'>
        <div class='conti'>
          <div class='colori'>
            <div class='colour' class='color1i'></div><div class='colour' class='color2i'></div><div class='colour'class='color3i'></div><div class='colour'class='color4i'></div>
            </div>
          <div  class='dropdowni'>
            <div class='datai'>Total: $</div><br>
            <div class='selecti'>
            <select class='select1i'>
              <option value='medium'>Medium</option>
              <option value='large'>Large</option>
              </select></div><br>
           <div class='selecti'>   
            <select class='quanti'>
              <option value='1'>1</option>
              <option value='2'>2</option>
              <option value='3'>3</option>
             </select></div><br>
            
          </div>
        </div> 
        <div class='pixi'>
        </div>
      </div>
     </div>
    <script>
    </script>
  </body>
</html>