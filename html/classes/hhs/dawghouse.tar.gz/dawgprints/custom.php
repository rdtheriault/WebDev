<html>
  <head>
    <link href="favicon.ico" rel="icon">
    <title>Custom</title>
    <link rel="stylesheet" href="style.css">
    <style>
      #none {
        color: red;
        margin-top:75px;
      }
      #bam {
        width: 975px;
        height: 200px;
        border: solid 2px maroon;
    	background-color: blue;
       	margin-top: 10px;
        margin-bottom: 10px;
        margin-left: 10px;
        margin-right: 10px;
      }
      #cust { 
        padding: 10px;
        font-family: serif;
        color: purple;
      }
    </style>
  </head>
  <body>
    <div id='main'>
      <img id="banner" src='pics/dawg-banner.png'>
        <div id='nav'>
          <div id='home' class='btn'>
            Main
            </div>
          <div id='shop' class='btn'>
            Shop
            </div>
          <div id='custom' class='btn'>
            Custom
            </div>
          <div id='contact' class='btn'>
            Contact Us
            </div>
          <div id='cart' class='btn'>
            Cart
            </div>
        </div>
		<h1 id='cust'>Current customization is found in the shop page now exclusive for shirts and sweatshirts. To customize your item, type in the name you would like to see on 
          the back of your shirt or sweatshirt in the box and click the checkbox.</h1>
          
    
   


    </div>
  </body>
</html>