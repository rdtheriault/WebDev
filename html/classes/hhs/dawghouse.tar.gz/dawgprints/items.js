var hat = {
  productname:"Dawg Hat",
  size:['Universal'],
  quantity:"",
  number:"0",
  color:['Gray', 'White', 'Purple'],
  type:"hat",
  imgsrc:"pics/hat1.jpg",
  price:"5",
  notes:"",
  customizable:"no"
};
var hat2 = {
  productname:"Hermiston H Hat",
  size:['Universal'],
  quantity:"",
  number:"0",
  color:['White'],
  type:"hat",
  imgsrc:"pics/Hat_white.jpg",
  price:"10",
  notes:"",
  customizable:"no"
};
var beanie1 = {
  productname:"Beanie Folded with H",
  size:['Universal'],
  quantity:"",
  number:"0",
  color:['Black'],
  type:"hat",
  imgsrc:"pics/Beanie_black.jpg",
  price:"10",
  notes:"",
  customizable:"no"
};
var beanie2 = {
  productname:"Beanie with H",
  size:['Universal'],
  quantity:"",
  number:"0",
  color:['Gray'],
  type:"hat",
  imgsrc:"pics/Beanie_grey.jpg",
  price:"10",
  notes:"",
  customizable:"no"
};
var shirt = {
  productname:"Grey Tee Shirt",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"shirt",
  imgsrc:"pics/shirt1.jpg",
  price:"10",
  notes:"*Add customization by checking below.",
  customizable:"yes"
};
var sweatshirt1 = {
  productname:"Black Sweater",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"sweater",
  imgsrc:"pics/sweatshirt1.jpg",
  price:"22",
  notes:"*Add customization by checking below.",
  customizable:"yes"
};
var sweatshirt2 = {
  productname:"Grey Sweater",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"sweater",
  imgsrc:"pics/sweatshirt2.jpg",
  price:"22",
  notes:"*Add customization by checking below.",
  customizable:"yes"
};