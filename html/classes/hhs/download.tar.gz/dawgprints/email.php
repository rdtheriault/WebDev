<?php
  $fn = strip_tags($_POST['fn']);
  $ln = $_POST['ln'];
  $em = $_POST['em'];
  $pn = $_POST['pn'];
  $cart = $_POST['cart'];
  //echo $cart;
	$items = explode(",", $cart);
  	$fill2 = "Thanks ".$fn." ". $ln ." for your order of: <br>";
	$fill = "Thanks ".$fn." ". $ln ." for your order of: \n\r " ;

	
	$arrlength = count($items);

	$count = 0;

    for($i = 0; $i < $arrlength; $i++) {
        
      	if ($count == 4) {
         $count = 0;
        }
      if ($count == 0) {
         $fill = $fill."Quantity: ".$items[$i]." - "; 
        $fill2 = $fill2."Quantity: ".$items[$i]." - ";
        }
      if ($count == 1) {
         $fill  = $fill."Size: ".$items[$i]." - "; 
        $fill2  = $fill2."Size: ".$items[$i]." - "; 
      }
      if ($count == 2) {
        $fill = $fill."Product Name: ".$items[$i]." - "; 
        $fill2 = $fill2."Product Name: ".$items[$i]." - "; 
        }
      if ($count == 3) {
         $fill = $fill."Price: ".$items[$i]." \n\r "; 
        $fill2 = $fill2."Price: ".$items[$i]." <br>"; 
        }
      
      	$count++;
    }


	$fill = $fill."Contact Info - Email: ". $em ." - Phone: ". $pn. " \n\r ";
	$fill2 = $fill2."Contact Info - Email: ". $em ." - Phone: ". $pn. " <br> ";
	$fill = $fill."If you did not purchase this order, please contact dawg.prints@hermiston.k12.or.us";
	echo $fill2;

	// Pear Mail Library
    require_once "/usr/share/php/Mail.php";

    $from = '<student-webmaster@hermistonsd.org>';
    $to = '<'.$em.'>';
    $subject = 'Thank you for your order from Dawg Prints';
    $body = $fill;

    $headers = array(
        'From' => $from,
        'To' => $to,
        'Subject' => $subject
    );

    $smtp = Mail::factory('smtp', array(
            'host' => 'ssl://smtp.gmail.com',
            'port' => '465',
            'auth' => true,
            'username' => 'student-webmaster@hermistonsd.org',
            'password' => 'HermistonSD',
  			'Content-type' => "text/plain; charset=iso-8859-1\r\n\r\n"
        ));

    $mail = $smtp->send($to, $headers, $body);

    if (PEAR::isError($mail)) {
        echo('<p>' . $mail->getMessage() . ' <strong>Please check your email to ensure it is correct and please place your order again.</strong></p>');
    } else {
        echo('<p>Order was successfully sent!</p>');
    }


?>