var hat= {
  productname:"Dawg Hat",
  size:['Universal'],
  quantity:"",
  number:"0",
  color:['Gray', 'White', 'Purple'],
  type:"hat",
  imgsrc:"pics/hat1.jpg",
  price:"5"
};
var shirt = {
  productname:"Grey Tee Shirt",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"shirt",
  imgsrc:"pics/shirt1.jpg",
  price:"10"
};
var sweatshirt1 = {
  productname:"Black Sweater",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"sweater",
  imgsrc:"pics/sweatshirt1.jpg",
  price:"22"
};
var sweatshirt2 = {
  productname:"Grey Sweater",
  size:['S','M','L','XL'],
  quantity:"",
  number:"1",
  color:['Gray', 'White', 'Purple'],
  type:"sweater",
  imgsrc:"pics/sweatshirt2.jpg",
  price:"22"
};