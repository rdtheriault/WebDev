<?php
require_once 'System.php';
var_dump(class_exists('System', false));
PHPINFO()
?>